package com.example.wensql;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class WebController {

    private Customer customer;

    @Autowired
    private CustomerController cusCont;

    @Autowired
    private RoomController roomCont;

    @GetMapping("/index")
    public String getMethodName(Model model) {
        return "main";
    }

    @PostMapping("/index")
    public String postMethodName(@RequestParam(name = "button") String val, @ModelAttribute Customer cus,
            @RequestParam(name = "code") String code, @RequestParam(name = "pass") String pass, Model model) {
        System.out.println("\n\n\n\n\n\n\n\n\n");
        if (val.equals("back")) {
            return "main";
        }
        if (val.equals("create")) {
            return "customer";
        }
        if (val.equals("login")) {
            model.addAttribute("value", "");
            return "login";
        }
        if (val.equals("signin")) {
            Customer c = cusCont.Get(code);
            if (c == null) {
                model.addAttribute("value", "invalid Code");
                return "login";
            }
            if (c.getPass().equals("2," + pass)) {
                model.addAttribute("roomElem", ShowRooms());
                customer = c;
                model.addAttribute("userName", c.getCusFName());
                return "show";
            } else {

                model.addAttribute("value", "invalid Password");
                return "login";
            }
        }
        if (val.equals("createCus")) {
            cusCont.Add(cus);
            customer = cus;
            model.addAttribute("roomElem", ShowRooms());
            model.addAttribute("userName", cus.getCusFName());
            return "show";
        }
        if (val.equals("room")) {
            System.out.println("\n\n123\n\n");
            Room room = roomCont.Get(Integer.parseInt(code));
            if (room != null) {
                if (customer.getCusCode().equals(room.getCusCode())) {
                    room.setCusCode("");
                    room.setrDate("");
                    room.setEmpty(true);
                    roomCont.Update(room);
                } else if (room.isEmpty()) {
                    room.setCusCode(customer.getCusCode());
                    room.setEmpty(false);
                    room.setrDate(LocalDate.now().toString());
                    roomCont.Update(room);
                }
            }
            model.addAttribute("roomElem", ShowRooms());
            model.addAttribute("userName", customer.getCusFName());
            return "show";
        }
        return "";
    }

    public String ShowRooms() {
        String str = "";
        for (int i = 0; i < 4; i++) {
            str += "<div class=\"row\">";
            for (int j = 0; j < 9; j++) {
                str += "<div class=\"elem\">";
                // str += (i + 1) + "0" + (j + 1);
                str += GetRoomElem((i + 1) + "0" + (j + 1));
                str += "</div>";
            }
            str += "</div>";
        }
        return str;
    }

    public String GetRoomElem(String num) {
        String str = "<form th:action = \"@{/input}\", method='post'>";
        str += "<input name=\"button\" type=\"hidden\" value=" + "room" + ">";
        str += "<input name=\"code\" type=\"hidden\" value=" + num + ">";
        str += "<input name=\"pass\" type=\"hidden\" value=\"back\">";
        str += "<input type=\"submit\" value = " + num + ">";
        str += "<br>" + roomCont.Get(Integer.parseInt(num)).getCusCode();
        str += "<br>" + roomCont.Get(Integer.parseInt(num)).getrDate();
        str += "</form>";
        return str;
    }

    public String GetCustomers() {
        List<Customer> cus = cusCont.GetAll();
        String str = "";
        str += "<tr>";
        str += "<td>" + "CusCode" + "</td>";
        str += "<td>" + "CusFName" + "</td>";
        str += "<td>" + "CusLName" + "</td>";
        str += "<td>" + "CusBirth" + "</td>";
        str += "<td>" + "CusReg" + "</td>";
        str += "<td>" + "CusPhone" + "</td>";
        str += "</tr>";
        for (int i = 0; i < cus.size(); i++) {
            if (cus.get(i).getCusCode().equals("")) {
                continue;
            }
            str += "<tr>";
            str += "<td>" + cus.get(i).getCusCode() + "</td>";
            str += "<td>" + cus.get(i).getCusFName() + "</td>";
            str += "<td>" + cus.get(i).getCusLName() + "</td>";
            str += "<td>" + cus.get(i).getCusBirth() + "</td>";
            str += "<td>" + cus.get(i).getCusReg() + "</td>";
            str += "<td>" + cus.get(i).getCusPhone() + "</td>";
            str += "</tr>";
        }
        return str;
    }

    public String GetRooms() {
        List<Room> cus = roomCont.GetAll();
        String str = "";
        str += "<tr>";
        str += "<td>" + "Room id" + "</td>";
        str += "<td>" + "Is empty" + "</td>";
        str += "<td>" + "Cus code" + "</td>";
        str += "<td>" + "R date" + "</td>";
        str += "</tr>";
        for (int i = 0; i < cus.size(); i++) {
            str += "<tr>";
            str += "<td>" + cus.get(i).getRoomId() + "</td>";
            str += "<td>" + cus.get(i).isEmpty() + "</td>";
            str += "<td>" + cus.get(i).getCusCode() + "</td>";
            str += "<td>" + cus.get(i).getrDate() + "</td>";
            str += "</tr>";
        }
        return str;
    }
}
