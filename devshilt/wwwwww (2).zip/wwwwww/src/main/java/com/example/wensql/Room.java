package com.example.wensql;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name =  "Room")
public class Room {
    @Id
    @Column(name= "room_id")
    private int roomId;
    @Column(name = "is_empty")
    private boolean isEmpty;
    @Column(name = "cus_code")
    private String cusCode;
    @Column(name = "r_date")
    private String rDate;

    public int getRoomId() {
        return roomId;
    }
    public String getrDate() {
        return rDate;
    }
    public void setrDate(String rDate) {
        this.rDate = rDate;
    }
    public String getCusCode() {
        return cusCode;
    }
    public void setCusCode(String cusCode) {
        this.cusCode = cusCode;
    }
    public boolean isEmpty() {
        return isEmpty;
    }
    public void setEmpty(boolean isEmpty) {
        this.isEmpty = isEmpty;
    }
    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }
}
