package com.example.wensql;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Process {
    @Autowired
    private LocRepo repo;

    public void Add(Location loc){
        repo.save(loc);
    }
    public Location Get(Long id){
        return repo.findById(id).get();
    }
    public List<Location> GetAll(){
        List<Location> list = new ArrayList<>();
        repo.findAll().forEach(list::add);
        return list;
    }
}
